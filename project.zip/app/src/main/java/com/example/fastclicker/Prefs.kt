package com.example.fastclicker

import android.content.Context

object Prefs {
    private const val NAME = "fast_clicker"
    private const val KEY_CPS = "cps"
    const val MIN_CPS = 1
    const val MAX_CPS = 200
    const val DEFAULT_CPS = 20

    fun getCps(context: Context): Int =
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .getInt(KEY_CPS, DEFAULT_CPS)
            .coerceIn(MIN_CPS, MAX_CPS)

    fun setCps(context: Context, value: Int) {
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_CPS, value.coerceIn(MIN_CPS, MAX_CPS))
            .apply()
    }
}
