package com.example.fastclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

class ClickService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ClickService? = null
            private set

        private const val BASE_FLAGS =
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL

        private val GREEN = Color.parseColor("#4ADE80")
        private val RED = Color.parseColor("#F87171")
        private val BAR = Color.parseColor("#F2191920")
        private val MUTED = Color.parseColor("#8A8A99")
        private val DARK_TEXT = Color.parseColor("#06210F")
    }

    private lateinit var windowManager: WindowManager
    private lateinit var workThread: HandlerThread
    private lateinit var workHandler: Handler

    private var controlBar: LinearLayout? = null
    private var controlParams: WindowManager.LayoutParams? = null
    private var targetView: TargetView? = null
    private var targetParams: WindowManager.LayoutParams? = null
    private var playButton: TextView? = null
    private var cpsLabel: TextView? = null
    private var holdLabel: TextView? = null
    private var collapsibleViews: List<View> = emptyList()
    private var collapsed = false

    @Volatile
    private var running = false

    @Volatile
    private var generation = 0

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        workThread = HandlerThread("clicker").apply { start() }
        workHandler = Handler(workThread.looper)
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        stopClicking()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        teardown()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        teardown()
        super.onDestroy()
    }

    private fun teardown() {
        if (!::windowManager.isInitialized) {
            instance = null
            return
        }
        hideOverlay()
        if (::workThread.isInitialized) workThread.quitSafely()
        instance = null
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun overlayParams(width: Int, height: Int) = WindowManager.LayoutParams(
        width,
        height,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        BASE_FLAGS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
    }

    fun showOverlay() {
        if (controlBar != null) return
        val metrics = resources.displayMetrics

        val target = TargetView(this)
        val targetLp = overlayParams(dp(64), dp(64)).apply {
            x = (metrics.widthPixels - dp(64)) / 2
            y = (metrics.heightPixels - dp(64)) / 2
        }
        attachDrag(target, target, targetLp)
        windowManager.addView(target, targetLp)
        targetView = target
        targetParams = targetLp

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = GradientDrawable().apply {
                setColor(BAR)
                cornerRadius = dp(32).toFloat()
            }
            elevation = dp(8).toFloat()
        }
        val barLp = overlayParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            x = dp(12)
            y = dp(120)
        }

        val grip = barButton("≡", 22f, MUTED) {}
        val minus = barButton("−", 24f, Color.WHITE) { changeCps(-1) }
        val label = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            minWidth = dp(60)
        }
        val plus = barButton("+", 24f, Color.WHITE) { changeCps(1) }
        val play = barButton("▶", 18f, DARK_TEXT, 48) { toggle() }
        val close = barButton("✕", 16f, MUTED) { hideOverlay() }

        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val holdRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val holdTitle = TextView(this).apply {
            text = "HOLD"
            textSize = 12f
            setTextColor(MUTED)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            minWidth = dp(56)
        }
        val holdMinus = barButton("−", 22f, Color.WHITE, 40) { changeHold(-1) }
        val holdValue = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            minWidth = dp(72)
        }
        val holdPlus = barButton("+", 22f, Color.WHITE, 40) { changeHold(1) }

        attachDrag(grip, bar, barLp) { toggleCollapsed() }

        topRow.addView(grip)
        topRow.addView(minus)
        topRow.addView(label)
        topRow.addView(plus)
        topRow.addView(play)
        topRow.addView(close)

        holdRow.addView(holdTitle)
        holdRow.addView(holdMinus)
        holdRow.addView(holdValue)
        holdRow.addView(holdPlus)

        bar.addView(
            topRow,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        bar.addView(
            holdRow,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        windowManager.addView(bar, barLp)
        controlBar = bar
        controlParams = barLp
        playButton = play
        cpsLabel = label
        holdLabel = holdValue
        collapsibleViews = listOf(minus, label, plus, close, holdRow)

        refreshCpsLabel()
        refreshHoldLabel()
        refreshPlay()
        applyCollapsed()
    }

    fun hideOverlay() {
        stopClicking()
        controlBar?.let {
            try {
                windowManager.removeView(it)
            } catch (e: IllegalArgumentException) {
            }
        }
        targetView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: IllegalArgumentException) {
            }
        }
        controlBar = null
        controlParams = null
        targetView = null
        targetParams = null
        playButton = null
        cpsLabel = null
        holdLabel = null
        collapsibleViews = emptyList()
    }

    private fun barButton(
        label: String,
        textSizeSp: Float,
        color: Int,
        sizeDp: Int = 44,
        onClick: () -> Unit
    ): TextView = TextView(this).apply {
        text = label
        textSize = textSizeSp
        setTextColor(color)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)).apply {
            setMargins(dp(2), 0, dp(2), 0)
        }
        setOnClickListener { onClick() }
    }

    private fun attachDrag(
        handle: View,
        window: View,
        params: WindowManager.LayoutParams,
        onTap: (() -> Unit)? = null
    ) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        handle.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - touchX
                    val dy = event.rawY - touchY
                    if (!moved && (dx * dx + dy * dy) > slop * slop) moved = true
                    if (moved) {
                        params.x = startX + dx.toInt()
                        params.y = startY + dy.toInt()
                        windowManager.updateViewLayout(window, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onTap?.invoke()
                    true
                }
                else -> true
            }
        }
    }

    private fun toggleCollapsed() {
        collapsed = !collapsed
        applyCollapsed()
    }

    private fun applyCollapsed() {
        val state = if (collapsed) View.GONE else View.VISIBLE
        collapsibleViews.forEach { it.visibility = state }
        val bar = controlBar ?: return
        val params = controlParams ?: return
        windowManager.updateViewLayout(bar, params)
    }

    private fun toggle() {
        if (running) stopClicking() else startClicking()
    }

    private fun changeCps(direction: Int) {
        val current = Prefs.getCps(this)
        val step = when {
            current < 20 -> 1
            current < 100 -> 5
            current < 200 -> 10
            else -> 25
        }
        Prefs.setCps(this, current + direction * step)
        refreshCpsLabel()
        if (running) {
            stopClicking()
            startClicking()
        }
    }

    private fun changeHold(direction: Int) {
        val current = Prefs.getHold(this)
        val step = when {
            current < 10 -> 1
            current < 50 -> 5
            current < 200 -> 10
            current < 500 -> 25
            else -> 50
        }
        Prefs.setHold(this, current + direction * step)
        refreshHoldLabel()
        if (running) {
            stopClicking()
            startClicking()
        }
    }

    private fun refreshHoldLabel() {
        val hold = Prefs.getHold(this)
        holdLabel?.text = if (hold <= 1) "tap" else "${hold}ms"
    }

    private fun refreshCpsLabel() {
        cpsLabel?.text = "${Prefs.getCps(this)}/s"
    }

    private fun refreshPlay() {
        playButton?.apply {
            text = if (running) "■" else "▶"
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(if (running) RED else GREEN)
            }
        }
        targetView?.invalidate()
    }

    private fun setTargetTouchable(touchable: Boolean) {
        val params = targetParams ?: return
        val view = targetView ?: return
        params.flags = if (touchable) {
            BASE_FLAGS
        } else {
            BASE_FLAGS or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        windowManager.updateViewLayout(view, params)
    }

    private fun startClicking() {
        if (running) return
        val view = targetView ?: return
        val location = IntArray(2)
        view.getLocationOnScreen(location)
        val x = location[0] + view.width / 2f
        val y = location[1] + view.height / 2f

        val cps = Prefs.getCps(this)
        val hold = Prefs.getHold(this).toLong()
        val spacing = max(max(2L, Math.round(1000.0 / cps)), hold + 1)
        val maxStrokes = GestureDescription.getMaxStrokeCount()
        val burst = max(1, min(maxStrokes, (100L / spacing).toInt()))

        val builder = GestureDescription.Builder()
        for (i in 0 until burst) {
            val path = Path().apply { moveTo(x, y) }
            builder.addStroke(GestureDescription.StrokeDescription(path, i * spacing, hold))
        }
        val gesture = builder.build()
        val period = burst * spacing

        running = true
        generation++
        val current = generation
        setTargetTouchable(false)
        refreshPlay()
        workHandler.post { fire(gesture, period, current) }
    }

    private fun stopClicking() {
        if (!running) return
        running = false
        generation++
        setTargetTouchable(true)
        refreshPlay()
    }

    private fun fire(gesture: GestureDescription, period: Long, gen: Int) {
        if (!running || gen != generation) return
        val started = SystemClock.uptimeMillis()
        val callback = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                scheduleNext(gesture, period, gen, started)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                scheduleNext(gesture, period, gen, started)
            }
        }
        val accepted = dispatchGesture(gesture, callback, workHandler)
        if (!accepted) {
            workHandler.postDelayed({ fire(gesture, period, gen) }, 50)
        }
    }

    private fun scheduleNext(gesture: GestureDescription, period: Long, gen: Int, started: Long) {
        if (!running || gen != generation) return
        val wait = period - (SystemClock.uptimeMillis() - started)
        if (wait > 0) {
            workHandler.postDelayed({ fire(gesture, period, gen) }, wait)
        } else {
            fire(gesture, period, gen)
        }
    }

    private inner class TargetView(context: Context) : View(context) {
        private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(3).toFloat()
        }
        private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

        override fun onDraw(canvas: Canvas) {
            val color = if (running) RED else GREEN
            val cx = width / 2f
            val cy = height / 2f
            glow.color = (color and 0x00FFFFFF) or 0x33000000
            canvas.drawCircle(cx, cy, width / 2f - dp(2), glow)
            ring.color = color
            canvas.drawCircle(cx, cy, width / 2f - dp(4), ring)
            dot.color = color
            canvas.drawCircle(cx, cy, dp(4).toFloat(), dot)
        }
    }
}
