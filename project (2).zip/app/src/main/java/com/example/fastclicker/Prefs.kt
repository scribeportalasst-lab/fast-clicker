package com.example.fastclicker

import android.content.Context

object Prefs {
    private const val NAME = "fast_clicker"
    private const val KEY_CPS = "cps"
    private const val KEY_HOLD = "hold"
    const val MIN_CPS = 1
    const val MAX_CPS = 500
    const val DEFAULT_CPS = 20
    const val MIN_HOLD = 1
    const val MAX_HOLD = 1000
    const val DEFAULT_HOLD = 1

    fun getCps(context: Context): Int =
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .getInt(KEY_CPS, DEFAULT_CPS)
            .coerceIn(MIN_CPS, MAX_CPS)

    fun setCps(context: Context, value: Int) {
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_CPS, value.coerceIn(MIN_CPS, MAX_CPS))
            .apply()
    }

    fun getHold(context: Context): Int =
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .getInt(KEY_HOLD, DEFAULT_HOLD)
            .coerceIn(MIN_HOLD, MAX_HOLD)

    fun setHold(context: Context, value: Int) {
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_HOLD, value.coerceIn(MIN_HOLD, MAX_HOLD))
            .apply()
    }
}
