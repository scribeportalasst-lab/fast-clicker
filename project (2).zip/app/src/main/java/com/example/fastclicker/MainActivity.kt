package com.example.fastclicker

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {

    private var serviceActive by mutableStateOf(false)
    private var cps by mutableIntStateOf(Prefs.DEFAULT_CPS)
    private var holdMs by mutableIntStateOf(Prefs.DEFAULT_HOLD)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF4ADE80),
                    onPrimary = Color(0xFF06210F),
                    background = Color(0xFF0F0F14),
                    surface = Color(0xFF1B1B23),
                    onSurface = Color.White
                )
            ) {
                FastClickerScreen(
                    serviceActive = serviceActive,
                    cps = cps,
                    onCpsChange = {
                        cps = it
                        Prefs.setCps(this, it)
                    },
                    holdMs = holdMs,
                    onHoldChange = {
                        holdMs = it
                        Prefs.setHold(this, it)
                    },
                    onOpenSettings = {
                        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    },
                    onShowControls = {
                        ClickService.instance?.showOverlay()
                        moveTaskToBack(true)
                    }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        serviceActive = ClickService.instance != null
        cps = Prefs.getCps(this)
        holdMs = Prefs.getHold(this)
    }
}

@Composable
private fun FastClickerScreen(
    serviceActive: Boolean,
    cps: Int,
    onCpsChange: (Int) -> Unit,
    holdMs: Int,
    onHoldChange: (Int) -> Unit,
    onOpenSettings: () -> Unit,
    onShowControls: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F0F14))
            .systemBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Fast Clicker",
            color = Color.White,
            fontSize = 34.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Free. No ads. No internet access.",
            color = Color(0xFF8A8A99),
            fontSize = 15.sp
        )

        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color(0xFF1B1B23),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .background(
                            if (serviceActive) Color(0xFF4ADE80) else Color(0xFFF87171),
                            CircleShape
                        )
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = if (serviceActive) "Clicker service is on" else "Clicker service is off",
                    color = Color.White,
                    fontSize = 16.sp
                )
            }
        }

        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color(0xFF1B1B23),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = "$cps taps per second",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Slider(
                    value = cps.toFloat(),
                    onValueChange = { onCpsChange(it.toInt()) },
                    valueRange = Prefs.MIN_CPS.toFloat()..Prefs.MAX_CPS.toFloat()
                )
                Text(
                    text = "Higher is faster. Your phone and the app you are tapping in decide the real limit.",
                    color = Color(0xFF8A8A99),
                    fontSize = 13.sp
                )
            }
        }

        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color(0xFF1B1B23),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = if (holdMs <= 1) "Quick tap" else "Hold each tap for $holdMs ms",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Slider(
                    value = holdMs.toFloat(),
                    onValueChange = { onHoldChange(it.toInt()) },
                    valueRange = Prefs.MIN_HOLD.toFloat()..Prefs.MAX_HOLD.toFloat()
                )
                Text(
                    text = "For games that say hold: every tap presses and holds for this long, then lets go. Keep it at 1 for normal fast tapping.",
                    color = Color(0xFF8A8A99),
                    fontSize = 13.sp
                )
            }
        }

        if (serviceActive) {
            Button(
                onClick = onShowControls,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
            ) {
                Text(text = "Show floating controls", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            }
        } else {
            Button(
                onClick = onOpenSettings,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
            ) {
                Text(text = "Turn on in Settings", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color(0xFF1B1B23),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "How to use",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text("1. Turn on Fast Clicker in Accessibility settings.", color = Color(0xFFB8B8C4), fontSize = 14.sp)
                Text("2. Come back here and tap Show floating controls.", color = Color(0xFFB8B8C4), fontSize = 14.sp)
                Text("3. Drag the green ring onto what you want tapped.", color = Color(0xFFB8B8C4), fontSize = 14.sp)
                Text("4. Press ▶ to start and ■ to stop.", color = Color(0xFFB8B8C4), fontSize = 14.sp)
            }
        }
    }
}
