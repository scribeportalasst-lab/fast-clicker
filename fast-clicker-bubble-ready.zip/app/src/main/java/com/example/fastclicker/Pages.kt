package com.example.fastclicker

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject

@Composable
private fun IntSlider(
    s: AppSettings,
    spec: Prefs.IntSpec,
    title: String,
    unit: String,
    hint: String? = null,
    sliderMax: Int = spec.max,
    offText: String? = null,
    enabled: Boolean = true
) {
    SliderRow(
        title = title,
        value = s.int(spec),
        min = spec.min,
        max = spec.max,
        unit = unit,
        onChange = { s.set(spec, it) },
        onFinished = { s.commit() },
        hint = hint,
        sliderMax = sliderMax,
        offText = offText,
        enabled = enabled
    )
}

@Composable
private fun FlagSwitch(s: AppSettings, spec: Prefs.FlagSpec, title: String, subtitle: String) {
    SwitchRow(title = title, subtitle = subtitle, checked = s.flag(spec)) {
        s.set(spec, it)
        s.commit()
    }
}

@Composable
fun SpeedPage(s: AppSettings, onBack: () -> Unit) {
    PageScaffold("Speed", "⚡", onBack) {
        BodyText("Tip: tap any number to type an exact value.")
        AppCard {
            IntSlider(
                s, Prefs.CPS, "Taps per second", "/s",
                hint = "How many taps each second. Your phone and the app you tap decide the real top speed."
            )
            IntSlider(
                s, Prefs.HOLD, "Hold time", "ms",
                hint = "1 is a quick tap. Raise it for games that say hold."
            )
        }
        AppCard {
            SectionTitle("HUMAN-LIKE")
            IntSlider(
                s, Prefs.JITTER, "Random timing", "%",
                hint = "Varies the time between taps so it looks less robotic.",
                offText = "Off"
            )
        }
    }
}

@Composable
fun TargetsPage(s: AppSettings, onBack: () -> Unit) {
    val swipe = s.flag(Prefs.SWIPE_MODE)
    PageScaffold("Targets", "🎯", onBack) {
        BodyText("Tip: tap any number to type an exact value.")
        AppCard {
            SectionTitle("MODE")
            SegmentedChoice(listOf("Tap", "Swipe"), if (swipe) 1 else 0) {
                s.set(Prefs.SWIPE_MODE, it == 1)
                s.commit()
            }
            BodyText(
                if (swipe) {
                    "Drag ring A to where the swipe starts and ring B to where it ends."
                } else {
                    "Drag each ring onto what you want tapped. With several rings, taps go to them in order."
                }
            )
        }
        AppCard {
            IntSlider(
                s, Prefs.POINTS, "Tap points", "",
                hint = "Number of rings on screen.",
                enabled = !swipe
            )
            IntSlider(
                s, Prefs.SWIPE_MS, "Swipe duration", "ms",
                hint = "How long each swipe takes from A to B.",
                enabled = swipe
            )
        }
        AppCard {
            SectionTitle("HUMAN-LIKE")
            IntSlider(
                s, Prefs.OFFSET, "Random position", "px",
                hint = "Each tap lands up to this far from the ring's center.",
                offText = "Off"
            )
        }
    }
}

@Composable
fun AutoStopPage(s: AppSettings, onBack: () -> Unit) {
    PageScaffold("Auto stop", "⏱️", onBack) {
        BodyText("Tip: tap any number to type an exact value.")
        AppCard {
            IntSlider(
                s, Prefs.START_DELAY, "Start delay", "s",
                hint = "Countdown after you press play, so you can get ready.",
                offText = "Off"
            )
        }
        AppCard {
            SectionTitle("STOP RULES")
            IntSlider(
                s, Prefs.MAX_TAPS, "Stop after taps", "",
                hint = "Stops once this many taps have been sent.",
                sliderMax = 10000,
                offText = "Off"
            )
            IntSlider(
                s, Prefs.MAX_SECONDS, "Stop after time", "s",
                hint = "In seconds. 3600 is one hour.",
                sliderMax = 3600,
                offText = "Off"
            )
            FlagSwitch(
                s, Prefs.STOP_ON_SCREEN_OFF, "Stop when screen turns off",
                "Stops clicking if the screen locks or goes dark."
            )
        }
    }
}

@Composable
fun ScreenPage(s: AppSettings, onBack: () -> Unit) {
    val keep = s.flag(Prefs.KEEP_BRIGHTNESS)
    PageScaffold("Screen", "🔆", onBack) {
        BodyText("Tip: tap any number to type an exact value.")
        AppCard {
            FlagSwitch(
                s, Prefs.KEEP_AWAKE, "Keep screen on",
                "Stops the screen from locking while the floating controls are showing."
            )
        }
        AppCard {
            FlagSwitch(
                s, Prefs.KEEP_BRIGHTNESS, "Keep my brightness",
                if (keep) {
                    "Brightness will not change while clicking."
                } else {
                    "The screen dims to the level below while clicking and returns to normal when you stop."
                }
            )
            IntSlider(
                s, Prefs.DIM, "Dim level", "%",
                hint = "Lower is darker. It can go darker than your normal brightness slider.",
                enabled = !keep
            )
        }
    }
}

@Composable
fun LookPage(s: AppSettings, onBack: () -> Unit) {
    PageScaffold("Look & feel", "🎨", onBack) {
        BodyText("Tip: tap any number to type an exact value.")
        AppCard {
            SectionTitle("ACCENT COLOR")
            ColorPicker(s.int(Prefs.ACCENT)) {
                s.set(Prefs.ACCENT, it)
                s.commit()
            }
        }
        AppCard {
            IntSlider(s, Prefs.BAR_OPACITY, "Control bar opacity", "%")
            IntSlider(s, Prefs.RING_SIZE, "Ring size", "dp")
        }
        AppCard {
            FlagSwitch(
                s, Prefs.HIDE_RINGS, "Fade rings while clicking",
                "Makes the rings almost see-through so they do not cover the screen."
            )
            FlagSwitch(
                s, Prefs.HAPTIC, "Vibrate on start and stop",
                "A short buzz when clicking starts or stops."
            )
        }
    }
}

@Composable
fun ProfilesPage(s: AppSettings, onBack: () -> Unit) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var name by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    PageScaffold("Profiles", "💾", onBack) {
        AppCard {
            SectionTitle("SAVE CURRENT SETTINGS")
            OutlinedTextField(
                value = name,
                onValueChange = { name = it.take(24) },
                singleLine = true,
                label = { Text("Profile name") },
                modifier = Modifier.fillMaxWidth()
            )
            AppButton(
                text = "Save profile",
                enabled = name.isNotBlank(),
                onClick = {
                    val clean = name.trim()
                    Prefs.saveProfile(context, clean)
                    s.reload()
                    message = "Saved \"$clean\""
                    name = ""
                }
            )
        }
        AppCard {
            SectionTitle("SAVED PROFILES")
            if (s.profileNames.isEmpty()) {
                BodyText("Nothing saved yet.")
            }
            s.profileNames.forEach { profile ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = profile,
                        color = Ui.TextColor,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = {
                        Prefs.loadProfile(context, profile)
                        s.reload()
                        s.commit()
                        message = "Loaded \"$profile\""
                    }) {
                        Text("Load", fontWeight = FontWeight.Bold)
                    }
                    TextButton(onClick = {
                        Prefs.deleteProfile(context, profile)
                        s.reload()
                        message = "Deleted \"$profile\""
                    }) {
                        Text("Delete", color = Ui.Danger, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        AppCard {
            SectionTitle("SHARE SETTINGS")
            AppButton(
                text = "Copy settings code",
                filled = false,
                onClick = {
                    clipboard.setText(AnnotatedString(Prefs.exportSettings(context).toString()))
                    message = "Settings code copied"
                }
            )
            OutlinedTextField(
                value = code,
                onValueChange = { code = it },
                label = { Text("Paste a settings code") },
                minLines = 2,
                maxLines = 4,
                modifier = Modifier.fillMaxWidth()
            )
            AppButton(
                text = "Apply code",
                enabled = code.isNotBlank(),
                onClick = {
                    try {
                        val ok = Prefs.importSettings(context, JSONObject(code.trim()))
                        s.reload()
                        s.commit()
                        message = if (ok) "Settings applied" else "That code has no settings in it"
                        if (ok) code = ""
                    } catch (e: Exception) {
                        message = "That code is not valid"
                    }
                }
            )
        }
        if (message.isNotEmpty()) {
            Text(
                text = message,
                color = MaterialTheme.colorScheme.primary,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun HelpPage(onBack: () -> Unit) {
    PageScaffold("Help", "❓", onBack) {
        HelpCard(
            "Getting started",
            "1. Turn on Fast Clicker in Accessibility settings.\n" +
                "2. Come back and tap Show floating controls.\n" +
                "3. Drag the ring onto what you want tapped.\n" +
                "4. Press ▶ to start and ■ to stop. Tap ≡ to shrink or expand the bar."
        )
        HelpCard(
            "Switch greyed out?",
            "Open Settings, then Apps, then Fast Clicker. Tap the three dots in the top right and choose Allow restricted settings. Then try the Accessibility switch again."
        )
        HelpCard(
            "Why it has a speed limit",
            "Taps are sent through Android's accessibility feature, which cannot space two taps closer than 2 ms apart. That makes 500 taps per second the most one point can get, and many apps and games count fewer than they receive."
        )
        HelpCard(
            "Games that say hold",
            "Raise Hold time so each tap presses and holds, then lower Taps per second to leave a short gap. Hold time plus the gap decides how many holds happen each second."
        )
        HelpCard(
            "Several points and swipes",
            "Targets lets you place up to 8 rings that are tapped in order, or switch to Swipe mode to drag from ring A to ring B again and again."
        )
        HelpCard(
            "Safety and privacy",
            "Fast Clicker has no internet access and never reads your screen. Dimming only changes its own window and goes back to normal when you stop. Some games treat auto clickers as cheating and can ban accounts, so use it at your own risk."
        )
    }
}

@Composable
private fun HelpCard(title: String, body: String) {
    AppCard {
        Text(text = title, color = Ui.TextColor, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        BodyText(body)
    }
}
