package com.example.fastclicker

import android.content.Context
import org.json.JSONObject

object Prefs {

    class IntSpec(val key: String, val min: Int, val max: Int, val def: Int)

    class FlagSpec(val key: String, val def: Boolean)

    val CPS = IntSpec("cps", 1, 500, 20)
    val HOLD = IntSpec("hold", 1, 1000, 1)
    val JITTER = IntSpec("jitter", 0, 90, 0)
    val OFFSET = IntSpec("offset", 0, 100, 0)
    val POINTS = IntSpec("points", 1, 8, 1)
    val SWIPE_MS = IntSpec("swipe_ms", 50, 5000, 300)
    val MAX_TAPS = IntSpec("max_taps", 0, 1000000, 0)
    val MAX_SECONDS = IntSpec("max_seconds", 0, 86400, 0)
    val START_DELAY = IntSpec("start_delay", 0, 60, 0)
    val DIM = IntSpec("dim", 1, 100, 10)
    val BAR_OPACITY = IntSpec("bar_opacity", 30, 100, 95)
    val RING_SIZE = IntSpec("ring_size", 40, 120, 64)
    val ACCENT = IntSpec("accent", 0, 5, 0)

    val SWIPE_MODE = FlagSpec("swipe_mode", false)
    val KEEP_BRIGHTNESS = FlagSpec("keep_brightness", true)
    val KEEP_AWAKE = FlagSpec("keep_awake", true)
    val HAPTIC = FlagSpec("haptic", true)
    val HIDE_RINGS = FlagSpec("hide_rings", false)
    val STOP_ON_SCREEN_OFF = FlagSpec("stop_screen_off", true)

    val allInts = listOf(
        CPS, HOLD, JITTER, OFFSET, POINTS, SWIPE_MS, MAX_TAPS, MAX_SECONDS,
        START_DELAY, DIM, BAR_OPACITY, RING_SIZE, ACCENT
    )

    val allFlags = listOf(
        SWIPE_MODE, KEEP_BRIGHTNESS, KEEP_AWAKE, HAPTIC, HIDE_RINGS, STOP_ON_SCREEN_OFF
    )

    val ACCENT_COLORS = intArrayOf(
        0xFF4ADE80.toInt(),
        0xFF60A5FA.toInt(),
        0xFFA78BFA.toInt(),
        0xFFFB923C.toInt(),
        0xFFF472B6.toInt(),
        0xFF22D3EE.toInt()
    )

    private const val NAME = "fast_clicker"
    private const val PROFILES = "profiles"

    private fun store(context: Context) =
        context.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun getInt(context: Context, spec: IntSpec): Int =
        store(context).getInt(spec.key, spec.def).coerceIn(spec.min, spec.max)

    fun setInt(context: Context, spec: IntSpec, value: Int) {
        store(context).edit().putInt(spec.key, value.coerceIn(spec.min, spec.max)).apply()
    }

    fun getFlag(context: Context, spec: FlagSpec): Boolean =
        store(context).getBoolean(spec.key, spec.def)

    fun setFlag(context: Context, spec: FlagSpec, value: Boolean) {
        store(context).edit().putBoolean(spec.key, value).apply()
    }

    fun exportSettings(context: Context): JSONObject {
        val json = JSONObject()
        allInts.forEach { json.put(it.key, getInt(context, it)) }
        allFlags.forEach { json.put(it.key, getFlag(context, it)) }
        return json
    }

    fun importSettings(context: Context, json: JSONObject): Boolean {
        var changed = false
        allInts.forEach { spec ->
            if (json.has(spec.key)) {
                val value = json.optInt(spec.key, Int.MIN_VALUE)
                if (value in spec.min..spec.max) {
                    setInt(context, spec, value)
                    changed = true
                }
            }
        }
        allFlags.forEach { spec ->
            if (json.has(spec.key)) {
                setFlag(context, spec, json.optBoolean(spec.key, spec.def))
                changed = true
            }
        }
        return changed
    }

    private fun readProfiles(context: Context): JSONObject =
        try {
            JSONObject(store(context).getString(PROFILES, "{}") ?: "{}")
        } catch (e: Exception) {
            JSONObject()
        }

    fun profileNames(context: Context): List<String> {
        val all = readProfiles(context)
        val names = mutableListOf<String>()
        val keys = all.keys()
        while (keys.hasNext()) {
            names.add(keys.next())
        }
        return names.sorted()
    }

    fun saveProfile(context: Context, name: String) {
        val all = readProfiles(context)
        all.put(name, exportSettings(context))
        store(context).edit().putString(PROFILES, all.toString()).apply()
    }

    fun loadProfile(context: Context, name: String): Boolean {
        val profile = readProfiles(context).optJSONObject(name) ?: return false
        return importSettings(context, profile)
    }

    fun deleteProfile(context: Context, name: String) {
        val all = readProfiles(context)
        all.remove(name)
        store(context).edit().putString(PROFILES, all.toString()).apply()
    }
}
