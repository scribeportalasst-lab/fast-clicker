package com.example.fastclicker

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

object Ui {
    val Background = Color(0xFF0F0F14)
    val Card = Color(0xFF1B1B23)
    val CardAlt = Color(0xFF2A2A35)
    val TextColor = Color.White
    val Muted = Color(0xFF9A9AA8)
    val Danger = Color(0xFFF87171)
    val OnAccent = Color(0xFF06210F)
    val Disabled = Color(0xFF4A4A57)
}

@Composable
fun PageScaffold(
    title: String,
    icon: String,
    onBack: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Ui.Background)
            .systemBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Ui.Card)
                    .clickable(onClick = onBack),
                contentAlignment = Alignment.Center
            ) {
                Text("←", color = Ui.TextColor, fontSize = 20.sp)
            }
            Spacer(modifier = Modifier.width(14.dp))
            Text(
                text = title,
                color = Ui.TextColor,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            IconTile(icon)
        }
        content()
    }
}

@Composable
fun IconTile(icon: String) {
    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)),
        contentAlignment = Alignment.Center
    ) {
        Text(text = icon, fontSize = 22.sp, color = Ui.TextColor)
    }
}

@Composable
fun AppCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Ui.Card)
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        content = content
    )
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text = text,
        color = Ui.Muted,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp
    )
}

@Composable
fun BodyText(text: String) {
    Text(text = text, color = Ui.Muted, fontSize = 14.sp, lineHeight = 20.sp)
}

@Composable
fun CategoryCard(title: String, subtitle: String, icon: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Ui.Card)
            .clickable(onClick = onClick)
            .padding(18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, color = Ui.TextColor, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = subtitle, color = Ui.Muted, fontSize = 13.sp)
        }
        Spacer(modifier = Modifier.width(12.dp))
        IconTile(icon)
    }
}

@Composable
fun AppButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    filled: Boolean = true,
    enabled: Boolean = true
) {
    val colors = if (filled) {
        ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = Ui.OnAccent,
            disabledContainerColor = Ui.CardAlt,
            disabledContentColor = Ui.Muted
        )
    } else {
        ButtonDefaults.buttonColors(
            containerColor = Ui.CardAlt,
            contentColor = Ui.TextColor,
            disabledContainerColor = Ui.CardAlt,
            disabledContentColor = Ui.Muted
        )
    }
    Button(
        onClick = onClick,
        enabled = enabled,
        shape = RoundedCornerShape(16.dp),
        colors = colors,
        modifier = modifier
            .fillMaxWidth()
            .height(52.dp)
    ) {
        Text(text = text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, color = Ui.TextColor, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = subtitle, color = Ui.Muted, fontSize = 13.sp)
        }
        Spacer(modifier = Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Ui.OnAccent,
                checkedTrackColor = MaterialTheme.colorScheme.primary,
                uncheckedThumbColor = Ui.Muted,
                uncheckedTrackColor = Ui.CardAlt,
                uncheckedBorderColor = Ui.Muted
            )
        )
    }
}

@Composable
fun SliderRow(
    title: String,
    value: Int,
    min: Int,
    max: Int,
    unit: String,
    onChange: (Int) -> Unit,
    onFinished: () -> Unit,
    hint: String? = null,
    sliderMax: Int = max,
    offText: String? = null,
    enabled: Boolean = true
) {
    var editing by remember { mutableStateOf(false) }
    val shown = if (offText != null && value == 0) offText else "$value$unit"
    val accent = MaterialTheme.colorScheme.primary

    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = title,
                color = if (enabled) Ui.TextColor else Ui.Muted,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f)
            )
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Ui.CardAlt)
                    .clickable(enabled = enabled) { editing = true }
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Text(
                    text = shown,
                    color = if (enabled) accent else Ui.Muted,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        Slider(
            value = value.coerceIn(min, sliderMax).toFloat(),
            onValueChange = { onChange(it.roundToInt()) },
            onValueChangeFinished = onFinished,
            valueRange = min.toFloat()..sliderMax.toFloat(),
            enabled = enabled,
            colors = SliderDefaults.colors(
                thumbColor = accent,
                activeTrackColor = accent,
                inactiveTrackColor = Ui.CardAlt,
                disabledThumbColor = Ui.Disabled,
                disabledActiveTrackColor = Ui.Disabled,
                disabledInactiveTrackColor = Ui.CardAlt
            )
        )
        if (hint != null) {
            Text(text = hint, color = Ui.Muted, fontSize = 13.sp)
        }
    }

    if (editing) {
        NumberDialog(
            title = title,
            unit = unit.trim(),
            min = min,
            max = max,
            current = value,
            onDismiss = { editing = false },
            onConfirm = {
                onChange(it)
                onFinished()
                editing = false
            }
        )
    }
}

@Composable
fun NumberDialog(
    title: String,
    unit: String,
    min: Int,
    max: Int,
    current: Int,
    onDismiss: () -> Unit,
    onConfirm: (Int) -> Unit
) {
    val start = current.toString()
    var field by remember { mutableStateOf(TextFieldValue(start, TextRange(0, start.length))) }
    val focus = remember { FocusRequester() }
    val parsed = field.text.toIntOrNull()
    val valid = parsed != null && parsed in min..max

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Ui.Card,
        title = { Text(text = title, color = Ui.TextColor, fontWeight = FontWeight.Bold) },
        text = {
            LaunchedEffect(Unit) {
                try {
                    focus.requestFocus()
                } catch (e: Exception) {
                }
            }
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = field,
                    onValueChange = { new ->
                        field = new.copy(text = new.text.filter { it.isDigit() }.take(9))
                    },
                    singleLine = true,
                    isError = !valid,
                    suffix = { Text(text = unit) },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            val number = parsed
                            if (number != null && valid) onConfirm(number)
                        }
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(focus)
                )
                Text(
                    text = if (valid) {
                        "Allowed: $min to $max"
                    } else {
                        "Enter a number from $min to $max"
                    },
                    color = if (valid) Ui.Muted else Ui.Danger,
                    fontSize = 13.sp
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = valid,
                onClick = {
                    val number = parsed
                    if (number != null && valid) onConfirm(number)
                }
            ) {
                Text(text = "Set", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(text = "Cancel", color = Ui.Muted)
            }
        }
    )
}

@Composable
fun SegmentedChoice(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Ui.CardAlt)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        options.forEachIndexed { index, label ->
            val on = index == selected
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(11.dp))
                    .background(if (on) MaterialTheme.colorScheme.primary else Color.Transparent)
                    .clickable { onSelect(index) }
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = label,
                    color = if (on) Ui.OnAccent else Ui.TextColor,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
fun ColorPicker(selected: Int, onSelect: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Prefs.ACCENT_COLORS.forEachIndexed { index, argb ->
            val picked = index == selected
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(Color(argb))
                    .then(if (picked) Modifier.border(3.dp, Color.White, CircleShape) else Modifier)
                    .clickable { onSelect(index) }
            )
        }
    }
}
