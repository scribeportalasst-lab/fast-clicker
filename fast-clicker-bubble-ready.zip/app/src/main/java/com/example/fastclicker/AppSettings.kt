package com.example.fastclicker

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class AppSettings(private val context: Context) {

    private val ints = mutableStateMapOf<String, Int>()
    private val flags = mutableStateMapOf<String, Boolean>()
    var profileNames by mutableStateOf<List<String>>(emptyList())
        private set

    init {
        reload()
    }

    fun reload() {
        Prefs.allInts.forEach { ints[it.key] = Prefs.getInt(context, it) }
        Prefs.allFlags.forEach { flags[it.key] = Prefs.getFlag(context, it) }
        profileNames = Prefs.profileNames(context)
    }

    fun int(spec: Prefs.IntSpec): Int = ints[spec.key] ?: spec.def

    fun flag(spec: Prefs.FlagSpec): Boolean = flags[spec.key] ?: spec.def

    fun set(spec: Prefs.IntSpec, value: Int) {
        val clean = value.coerceIn(spec.min, spec.max)
        Prefs.setInt(context, spec, clean)
        ints[spec.key] = clean
    }

    fun set(spec: Prefs.FlagSpec, value: Boolean) {
        Prefs.setFlag(context, spec, value)
        flags[spec.key] = value
    }

    fun commit() {
        ClickService.instance?.reloadSettings()
    }
}
