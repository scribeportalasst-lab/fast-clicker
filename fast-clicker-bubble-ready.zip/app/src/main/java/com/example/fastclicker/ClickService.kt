package com.example.fastclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class ClickService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ClickService? = null
            private set

        private const val BASE_FLAGS =
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL

        private val RED = Color.parseColor("#F87171")
        private val AMBER = Color.parseColor("#FBBF24")
        private val BAR = Color.parseColor("#F2191920")
        private val MUTED = Color.parseColor("#9A9AA8")
        private val DARK_TEXT = Color.parseColor("#06210F")
    }

    private class RunConfig(
        val xs: FloatArray,
        val ys: FloatArray,
        val spacing: Long,
        val hold: Long,
        val jitter: Int,
        val offset: Int,
        val burst: Int,
        val maxTaps: Long,
        val maxMillis: Long,
        val swipe: Boolean,
        val swipeMs: Long
    )

    private class Built(val gesture: GestureDescription, val count: Int, val period: Long)

    private lateinit var windowManager: WindowManager
    private lateinit var workThread: HandlerThread
    private lateinit var workHandler: Handler
    private val mainHandler = Handler(Looper.getMainLooper())

    private var controlBar: LinearLayout? = null
    private var controlParams: WindowManager.LayoutParams? = null
    private val ringViews = mutableListOf<RingView>()
    private val ringParams = mutableListOf<WindowManager.LayoutParams>()
    private val savedPositions = HashMap<Int, IntArray>()
    private var savedBar: IntArray? = null

    private var playButton: TextView? = null
    private var cpsLabel: TextView? = null
    private var holdLabel: TextView? = null
    private var modeButton: TextView? = null
    private var dimLabel: TextView? = null
    private var statusLabel: TextView? = null
    private var collapsibleViews: List<View> = emptyList()
    private var collapsed = false

    @Volatile
    private var running = false

    @Volatile
    private var counting = false

    @Volatile
    private var generation = 0

    @Volatile
    private var tapsDone = 0L

    private var runStart = 0L
    private var tapIndex = 0L
    private var config: RunConfig? = null
    private var screenReceiver: BroadcastReceiver? = null
    private var vibrator: Vibrator? = null
    private var accent = Color.parseColor("#4ADE80")

    @Suppress("DEPRECATION")
    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        workThread = HandlerThread("clicker").apply { start() }
        workHandler = Handler(workThread.looper)
        vibrator = if (Build.VERSION.SDK_INT >= 31) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (Prefs.getFlag(this@ClickService, Prefs.STOP_ON_SCREEN_OFF)) {
                    stopClicking()
                }
            }
        }
        registerReceiver(receiver, IntentFilter(Intent.ACTION_SCREEN_OFF))
        screenReceiver = receiver
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        stopClicking()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        teardown()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        teardown()
        super.onDestroy()
    }

    private fun teardown() {
        if (!::windowManager.isInitialized) {
            instance = null
            return
        }
        hideOverlay()
        screenReceiver?.let {
            try {
                unregisterReceiver(it)
            } catch (e: IllegalArgumentException) {
            }
        }
        screenReceiver = null
        if (::workThread.isInitialized) workThread.quitSafely()
        instance = null
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun baseFlags(): Int =
        if (Prefs.getFlag(this, Prefs.KEEP_AWAKE)) {
            BASE_FLAGS or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        } else {
            BASE_FLAGS
        }

    private fun overlayParams(width: Int, height: Int) = WindowManager.LayoutParams(
        width,
        height,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        baseFlags(),
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
    }

    private fun ringCount(): Int =
        if (Prefs.getFlag(this, Prefs.SWIPE_MODE)) 2 else Prefs.getInt(this, Prefs.POINTS)

    fun showOverlay() {
        if (controlBar != null) return
        accent = Prefs.ACCENT_COLORS[Prefs.getInt(this, Prefs.ACCENT)]
        buildRings()
        buildBar()
    }

    fun reloadSettings() {
        if (controlBar == null || running || counting) return
        hideOverlay()
        showOverlay()
    }

    private fun buildRings() {
        val metrics = resources.displayMetrics
        val size = dp(Prefs.getInt(this, Prefs.RING_SIZE))
        val count = ringCount()
        val swipe = Prefs.getFlag(this, Prefs.SWIPE_MODE)
        val step = size + dp(12)
        for (i in 0 until count) {
            val label = when {
                swipe -> if (i == 0) "A" else "B"
                count > 1 -> (i + 1).toString()
                else -> ""
            }
            val view = RingView(this, label)
            val saved = savedPositions[i]
            val lp = overlayParams(size, size).apply {
                x = saved?.get(0) ?: ((metrics.widthPixels - size) / 2 + i * step - ((count - 1) * step) / 2)
                y = saved?.get(1) ?: ((metrics.heightPixels - size) / 2)
            }
            attachDrag(view, view, lp, onMove = { savedPositions[i] = intArrayOf(lp.x, lp.y) })
            windowManager.addView(view, lp)
            ringViews.add(view)
            ringParams.add(lp)
        }
    }

    private fun buildBar() {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = GradientDrawable().apply {
                setColor(BAR)
                cornerRadius = dp(28).toFloat()
            }
            elevation = dp(8).toFloat()
            alpha = Prefs.getInt(this@ClickService, Prefs.BAR_OPACITY) / 100f
        }
        val start = savedBar
        val barLp = overlayParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            x = start?.get(0) ?: dp(12)
            y = start?.get(1) ?: dp(120)
        }

        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val grip = barButton("≡", 22f, MUTED) {}
        val minus = barButton("−", 24f, Color.WHITE) { changeCps(-1) }
        val label = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            minWidth = dp(60)
        }
        val plus = barButton("+", 24f, Color.WHITE) { changeCps(1) }
        val play = barButton("▶", 18f, DARK_TEXT, 48) { toggle() }
        val close = barButton("✕", 16f, MUTED) { hideOverlay() }

        val holdRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val holdTitle = TextView(this).apply {
            text = "HOLD"
            textSize = 12f
            setTextColor(MUTED)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            minWidth = dp(56)
        }
        val holdMinus = barButton("−", 22f, Color.WHITE, 40) { changeHold(-1) }
        val holdValue = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            minWidth = dp(72)
        }
        val holdPlus = barButton("+", 22f, Color.WHITE, 40) { changeHold(1) }

        val dimRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val modeBtn = TextView(this).apply {
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(DARK_TEXT)
            minWidth = dp(56)
            setPadding(dp(6), dp(6), dp(6), dp(6))
            setOnClickListener { toggleKeepBrightness() }
        }
        val dimMinus = barButton("−", 22f, Color.WHITE, 40) { changeDim(-1) }
        val dimValue = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            minWidth = dp(72)
        }
        val dimPlus = barButton("+", 22f, Color.WHITE, 40) { changeDim(1) }

        val status = TextView(this).apply {
            text = "Ready"
            textSize = 11f
            setTextColor(MUTED)
            gravity = Gravity.CENTER
            setPadding(0, dp(2), 0, 0)
        }

        attachDrag(grip, bar, barLp, onMove = { savedBar = intArrayOf(barLp.x, barLp.y) }) {
            toggleCollapsed()
        }

        topRow.addView(grip)
        topRow.addView(minus)
        topRow.addView(label)
        topRow.addView(plus)
        topRow.addView(play)
        topRow.addView(close)

        holdRow.addView(holdTitle)
        holdRow.addView(holdMinus)
        holdRow.addView(holdValue)
        holdRow.addView(holdPlus)

        dimRow.addView(modeBtn)
        dimRow.addView(dimMinus)
        dimRow.addView(dimValue)
        dimRow.addView(dimPlus)

        bar.addView(
            topRow,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        bar.addView(
            holdRow,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        bar.addView(
            dimRow,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        bar.addView(
            status,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        windowManager.addView(bar, barLp)
        controlBar = bar
        controlParams = barLp
        playButton = play
        cpsLabel = label
        holdLabel = holdValue
        modeButton = modeBtn
        dimLabel = dimValue
        statusLabel = status
        collapsibleViews = listOf(minus, label, plus, close, holdRow, dimRow, status)

        refreshCpsLabel()
        refreshHoldLabel()
        refreshDim()
        refreshPlay()
        applyCollapsed()
    }

    fun hideOverlay() {
        stopClicking(true)
        controlBar?.let { safeRemove(it) }
        ringViews.forEach { safeRemove(it) }
        ringViews.clear()
        ringParams.clear()
        controlBar = null
        controlParams = null
        playButton = null
        cpsLabel = null
        holdLabel = null
        modeButton = null
        dimLabel = null
        statusLabel = null
        collapsibleViews = emptyList()
    }

    private fun safeRemove(view: View) {
        try {
            windowManager.removeView(view)
        } catch (e: IllegalArgumentException) {
        }
    }

    private fun barButton(
        label: String,
        textSizeSp: Float,
        color: Int,
        sizeDp: Int = 44,
        onClick: () -> Unit
    ): TextView = TextView(this).apply {
        text = label
        textSize = textSizeSp
        setTextColor(color)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)).apply {
            setMargins(dp(2), 0, dp(2), 0)
        }
        setOnClickListener { onClick() }
    }

    private fun attachDrag(
        handle: View,
        window: View,
        params: WindowManager.LayoutParams,
        onMove: (() -> Unit)? = null,
        onTap: (() -> Unit)? = null
    ) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        handle.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - touchX
                    val dy = event.rawY - touchY
                    if (!moved && (dx * dx + dy * dy) > slop * slop) moved = true
                    if (moved) {
                        params.x = startX + dx.toInt()
                        params.y = startY + dy.toInt()
                        windowManager.updateViewLayout(window, params)
                        onMove?.invoke()
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onTap?.invoke()
                    true
                }
                else -> true
            }
        }
    }

    private fun toggleCollapsed() {
        collapsed = !collapsed
        applyCollapsed()
    }

    private fun applyCollapsed() {
        val state = if (collapsed) View.GONE else View.VISIBLE
        collapsibleViews.forEach { it.visibility = state }
        val bar = controlBar ?: return
        val params = controlParams ?: return
        windowManager.updateViewLayout(bar, params)
    }

    private fun toggle() {
        if (running || counting) stopClicking() else startClicking()
    }

    private fun changeCps(direction: Int) {
        val current = Prefs.getInt(this, Prefs.CPS)
        val step = when {
            current < 20 -> 1
            current < 100 -> 5
            current < 200 -> 10
            else -> 25
        }
        Prefs.setInt(this, Prefs.CPS, current + direction * step)
        refreshCpsLabel()
        restartRun()
    }

    private fun changeHold(direction: Int) {
        val current = Prefs.getInt(this, Prefs.HOLD)
        val step = when {
            current < 10 -> 1
            current < 50 -> 5
            current < 200 -> 10
            current < 500 -> 25
            else -> 50
        }
        Prefs.setInt(this, Prefs.HOLD, current + direction * step)
        refreshHoldLabel()
        restartRun()
    }

    private fun changeDim(direction: Int) {
        val current = Prefs.getInt(this, Prefs.DIM)
        val step = when {
            current < 10 -> 1
            current < 50 -> 5
            else -> 10
        }
        Prefs.setInt(this, Prefs.DIM, current + direction * step)
        refreshDim()
        applyBrightness()
    }

    private fun toggleKeepBrightness() {
        Prefs.setFlag(this, Prefs.KEEP_BRIGHTNESS, !Prefs.getFlag(this, Prefs.KEEP_BRIGHTNESS))
        refreshDim()
        applyBrightness()
    }

    private fun refreshCpsLabel() {
        cpsLabel?.text = "${Prefs.getInt(this, Prefs.CPS)}/s"
    }

    private fun refreshHoldLabel() {
        val hold = Prefs.getInt(this, Prefs.HOLD)
        holdLabel?.text = if (hold <= 1) "tap" else "${hold}ms"
    }

    private fun refreshDim() {
        val keep = Prefs.getFlag(this, Prefs.KEEP_BRIGHTNESS)
        val tint = if (keep) accent else RED
        modeButton?.apply {
            text = if (keep) "KEEP" else "DIM"
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(tint)
            }
        }
        dimLabel?.apply {
            text = "${Prefs.getInt(this@ClickService, Prefs.DIM)}%"
            alpha = if (keep) 0.4f else 1f
        }
    }

    private fun refreshPlay() {
        val color = when {
            running -> RED
            counting -> AMBER
            else -> accent
        }
        playButton?.apply {
            if (!counting) text = if (running) "■" else "▶"
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(color)
            }
        }
        val fade = running && Prefs.getFlag(this, Prefs.HIDE_RINGS)
        ringViews.forEach {
            it.alpha = if (fade) 0.12f else 1f
            it.invalidate()
        }
    }

    private fun setRingsTouchable(touchable: Boolean) {
        for (i in ringViews.indices) {
            val params = ringParams[i]
            params.flags = if (touchable) {
                baseFlags()
            } else {
                baseFlags() or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            }
            windowManager.updateViewLayout(ringViews[i], params)
        }
    }

    private fun applyBrightness() {
        val bar = controlBar ?: return
        val params = controlParams ?: return
        val dim = running && !Prefs.getFlag(this, Prefs.KEEP_BRIGHTNESS)
        val level = Prefs.getInt(this, Prefs.DIM) / 100f
        params.screenBrightness = if (dim) {
            max(0.001f, level * level)
        } else {
            WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        }
        windowManager.updateViewLayout(bar, params)
    }

    private fun buzz() {
        if (!Prefs.getFlag(this, Prefs.HAPTIC)) return
        val device = vibrator ?: return
        try {
            device.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) {
        }
    }

    private fun startClicking() {
        if (running || counting) return
        if (ringViews.isEmpty()) return
        val delay = Prefs.getInt(this, Prefs.START_DELAY)
        if (delay <= 0) {
            beginRun()
            return
        }
        counting = true
        generation++
        val gen = generation
        refreshPlay()
        countdownTick(delay, gen)
    }

    private fun countdownTick(remaining: Int, gen: Int) {
        if (!counting || gen != generation) return
        if (remaining <= 0) {
            counting = false
            beginRun()
            return
        }
        playButton?.text = remaining.toString()
        mainHandler.postDelayed({ countdownTick(remaining - 1, gen) }, 1000)
    }

    private fun beginRun() {
        val cps = Prefs.getInt(this, Prefs.CPS)
        val hold = Prefs.getInt(this, Prefs.HOLD).toLong()
        val swipe = Prefs.getFlag(this, Prefs.SWIPE_MODE)
        val count = ringViews.size
        val xs = FloatArray(count)
        val ys = FloatArray(count)
        val location = IntArray(2)
        for (i in 0 until count) {
            val view = ringViews[i]
            view.getLocationOnScreen(location)
            xs[i] = location[0] + view.width / 2f
            ys[i] = location[1] + view.height / 2f
        }
        val base = max(2L, Math.round(1000.0 / cps))
        val spacing = if (swipe) base else max(base, hold + 1)
        val maxStrokes = GestureDescription.getMaxStrokeCount()
        val burst = max(1, min(maxStrokes, (100L / spacing).toInt()))
        val maxSeconds = Prefs.getInt(this, Prefs.MAX_SECONDS).toLong()
        config = RunConfig(
            xs = xs,
            ys = ys,
            spacing = spacing,
            hold = hold,
            jitter = Prefs.getInt(this, Prefs.JITTER),
            offset = Prefs.getInt(this, Prefs.OFFSET),
            burst = burst,
            maxTaps = Prefs.getInt(this, Prefs.MAX_TAPS).toLong(),
            maxMillis = maxSeconds * 1000L,
            swipe = swipe,
            swipeMs = Prefs.getInt(this, Prefs.SWIPE_MS).toLong()
        )
        tapsDone = 0L
        tapIndex = 0L
        runStart = SystemClock.uptimeMillis()
        counting = false
        running = true
        generation++
        val gen = generation
        setRingsTouchable(false)
        refreshPlay()
        applyBrightness()
        buzz()
        startStatusTicker(gen)
        workHandler.post { fire(gen) }
    }

    private fun restartRun() {
        if (!running) return
        stopClicking(true)
        beginRun()
    }

    private fun stopClicking(quiet: Boolean = false) {
        val wasRunning = running
        if (!wasRunning && !counting) return
        running = false
        counting = false
        generation++
        setRingsTouchable(true)
        refreshPlay()
        applyBrightness()
        if (wasRunning) {
            statusLabel?.text = "Stopped · ${"%,d".format(tapsDone)} taps"
        }
        if (!quiet) buzz()
    }

    private fun startStatusTicker(gen: Int) {
        mainHandler.post(object : Runnable {
            override fun run() {
                if (!running || gen != generation) return
                val seconds = (SystemClock.uptimeMillis() - runStart) / 1000
                val clock = "${seconds / 60}:${(seconds % 60).toString().padStart(2, '0')}"
                statusLabel?.text = "${"%,d".format(tapsDone)} taps · $clock"
                mainHandler.postDelayed(this, 250)
            }
        })
    }

    private fun requestStop(gen: Int) {
        mainHandler.post {
            if (gen == generation) stopClicking()
        }
    }

    private fun fire(gen: Int) {
        if (!running || gen != generation) return
        val cfg = config ?: return
        if (cfg.maxMillis > 0 && SystemClock.uptimeMillis() - runStart >= cfg.maxMillis) {
            requestStop(gen)
            return
        }
        val remaining = if (cfg.maxTaps > 0) cfg.maxTaps - tapsDone else Long.MAX_VALUE
        if (remaining <= 0L) {
            requestStop(gen)
            return
        }
        val built = if (cfg.swipe) {
            buildSwipe(cfg)
        } else {
            buildTaps(cfg, min(cfg.burst.toLong(), remaining).toInt())
        }
        val started = SystemClock.uptimeMillis()
        val callback = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                tapsDone += built.count
                scheduleNext(built.period, gen, started)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                scheduleNext(built.period, gen, started)
            }
        }
        val accepted = dispatchGesture(built.gesture, callback, workHandler)
        if (!accepted) {
            workHandler.postDelayed({ fire(gen) }, 50)
        }
    }

    private fun scheduleNext(period: Long, gen: Int, started: Long) {
        if (!running || gen != generation) return
        val wait = period - (SystemClock.uptimeMillis() - started)
        if (wait > 0) {
            workHandler.postDelayed({ fire(gen) }, wait)
        } else {
            fire(gen)
        }
    }

    private fun jittered(base: Long, percent: Int): Long {
        if (percent <= 0) return base
        val factor = 1.0 + Random.nextInt(-percent, percent + 1) / 100.0
        return max(2L, Math.round(base * factor))
    }

    private fun jitterPos(value: Float, offset: Int, limit: Int): Float {
        if (offset <= 0) return value
        val moved = value + Random.nextInt(-offset, offset + 1)
        return moved.coerceIn(0f, limit - 1f)
    }

    private fun buildTaps(cfg: RunConfig, count: Int): Built {
        val metrics = resources.displayMetrics
        val builder = GestureDescription.Builder()
        var start = 0L
        for (i in 0 until count) {
            val index = (tapIndex % cfg.xs.size).toInt()
            tapIndex++
            val path = Path().apply {
                moveTo(
                    jitterPos(cfg.xs[index], cfg.offset, metrics.widthPixels),
                    jitterPos(cfg.ys[index], cfg.offset, metrics.heightPixels)
                )
            }
            builder.addStroke(GestureDescription.StrokeDescription(path, start, cfg.hold))
            start += max(jittered(cfg.spacing, cfg.jitter), cfg.hold + 1)
        }
        return Built(builder.build(), count, start)
    }

    private fun buildSwipe(cfg: RunConfig): Built {
        val metrics = resources.displayMetrics
        val path = Path().apply {
            moveTo(
                jitterPos(cfg.xs[0], cfg.offset, metrics.widthPixels),
                jitterPos(cfg.ys[0], cfg.offset, metrics.heightPixels)
            )
            lineTo(
                jitterPos(cfg.xs[1], cfg.offset, metrics.widthPixels),
                jitterPos(cfg.ys[1], cfg.offset, metrics.heightPixels)
            )
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, cfg.swipeMs)
        val gap = max(jittered(cfg.spacing, cfg.jitter), cfg.swipeMs + 20L)
        return Built(GestureDescription.Builder().addStroke(stroke).build(), 1, gap)
    }

    private inner class RingView(context: Context, private val label: String) : View(context) {
        private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(3).toFloat()
        }
        private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }

        override fun onDraw(canvas: Canvas) {
            val color = if (running) RED else accent
            val cx = width / 2f
            val cy = height / 2f
            glow.color = (color and 0x00FFFFFF) or 0x33000000
            canvas.drawCircle(cx, cy, width / 2f - dp(2), glow)
            ring.color = color
            canvas.drawCircle(cx, cy, width / 2f - dp(4), ring)
            dot.color = color
            canvas.drawCircle(cx, cy, dp(4).toFloat(), dot)
            if (label.isNotEmpty()) {
                labelPaint.color = color
                labelPaint.textSize = width * 0.26f
                canvas.drawText(label, cx, cy - width * 0.13f, labelPaint)
            }
        }
    }
}
