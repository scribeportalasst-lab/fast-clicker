package com.example.fastclicker

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private enum class Page { Home, Speed, Targets, AutoStop, Screen, Look, Profiles, Help }

class MainActivity : ComponentActivity() {

    private lateinit var settings: AppSettings
    private var serviceActive by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = AppSettings(this)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            val accent = Color(Prefs.ACCENT_COLORS[settings.int(Prefs.ACCENT)])
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = accent,
                    onPrimary = Ui.OnAccent,
                    background = Ui.Background,
                    onBackground = Ui.TextColor,
                    surface = Ui.Card,
                    onSurface = Ui.TextColor,
                    surfaceVariant = Ui.CardAlt,
                    onSurfaceVariant = Ui.Muted
                )
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Ui.Background,
                    contentColor = Ui.TextColor
                ) {
                    var page by remember { mutableStateOf(Page.Home) }
                    BackHandler(enabled = page != Page.Home) { page = Page.Home }
                    when (page) {
                        Page.Home -> HomeScreen(
                            s = settings,
                            serviceActive = serviceActive,
                            onOpenSettings = {
                                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                            },
                            onShowControls = {
                                ClickService.instance?.showOverlay()
                                moveTaskToBack(true)
                            },
                            onOpen = { page = it }
                        )
                        Page.Speed -> SpeedPage(settings) { page = Page.Home }
                        Page.Targets -> TargetsPage(settings) { page = Page.Home }
                        Page.AutoStop -> AutoStopPage(settings) { page = Page.Home }
                        Page.Screen -> ScreenPage(settings) { page = Page.Home }
                        Page.Look -> LookPage(settings) { page = Page.Home }
                        Page.Profiles -> ProfilesPage(settings) { page = Page.Home }
                        Page.Help -> HelpPage { page = Page.Home }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        serviceActive = ClickService.instance != null
        settings.reload()
    }
}

@Composable
private fun HomeScreen(
    s: AppSettings,
    serviceActive: Boolean,
    onOpenSettings: () -> Unit,
    onShowControls: () -> Unit,
    onOpen: (Page) -> Unit
) {
    val hold = s.int(Prefs.HOLD)
    val speedLine = "${s.int(Prefs.CPS)} taps/s · " + if (hold <= 1) "quick tap" else "hold ${hold}ms"

    val points = s.int(Prefs.POINTS)
    val targetsLine = when {
        s.flag(Prefs.SWIPE_MODE) -> "Swipe from A to B"
        points == 1 -> "1 tap point"
        else -> "$points tap points"
    }

    val stopParts = mutableListOf<String>()
    if (s.int(Prefs.START_DELAY) > 0) stopParts.add("start in ${s.int(Prefs.START_DELAY)}s")
    if (s.int(Prefs.MAX_TAPS) > 0) stopParts.add("stop at ${s.int(Prefs.MAX_TAPS)} taps")
    if (s.int(Prefs.MAX_SECONDS) > 0) stopParts.add("stop after ${s.int(Prefs.MAX_SECONDS)}s")
    val stopLine = if (stopParts.isEmpty()) "No limits set" else stopParts.joinToString(" · ")

    val screenLine = listOf(
        if (s.flag(Prefs.KEEP_AWAKE)) "Screen stays on" else "Screen can sleep",
        if (s.flag(Prefs.KEEP_BRIGHTNESS)) "brightness unchanged" else "dims to ${s.int(Prefs.DIM)}%"
    ).joinToString(" · ")

    val lookLine = "Bar ${s.int(Prefs.BAR_OPACITY)}% · ring ${s.int(Prefs.RING_SIZE)}dp"
    val profilesLine = "${s.profileNames.size} saved"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Ui.Background)
            .systemBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column {
            Text(
                text = "Fast Clicker",
                color = Ui.TextColor,
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Free. No ads. No internet access.",
                color = Ui.Muted,
                fontSize = 15.sp
            )
        }

        AppCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .clip(CircleShape)
                        .background(if (serviceActive) MaterialTheme.colorScheme.primary else Ui.Danger)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = if (serviceActive) "Clicker service is on" else "Clicker service is off",
                    color = Ui.TextColor,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
            if (!serviceActive) {
                BodyText("Turn on Fast Clicker in Accessibility settings, then come back here.")
            }
            AppButton(
                text = if (serviceActive) "Show floating controls" else "Turn on in Settings",
                onClick = if (serviceActive) onShowControls else onOpenSettings
            )
        }

        SectionTitle("SETTINGS")
        CategoryCard("Speed", speedLine, "⚡") { onOpen(Page.Speed) }
        CategoryCard("Targets", targetsLine, "🎯") { onOpen(Page.Targets) }
        CategoryCard("Auto stop", stopLine, "⏱️") { onOpen(Page.AutoStop) }
        CategoryCard("Screen", screenLine, "🔆") { onOpen(Page.Screen) }
        CategoryCard("Look & feel", lookLine, "🎨") { onOpen(Page.Look) }
        CategoryCard("Profiles", profilesLine, "💾") { onOpen(Page.Profiles) }
        CategoryCard("Help", "How it works, tips and limits", "❓") { onOpen(Page.Help) }
    }
}
